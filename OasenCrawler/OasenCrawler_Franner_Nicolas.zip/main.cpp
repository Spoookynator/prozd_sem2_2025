#include <iostream>
#include "game.h"

int main() {
	Game::startGame();
}