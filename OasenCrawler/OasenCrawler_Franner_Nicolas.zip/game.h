#pragma once

namespace Game {
	void startGame();
}