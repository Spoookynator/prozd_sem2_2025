#pragma once
#include "bot.h"

void handleBotInput(Bot* bot);

void selectBotTypes(Bot* &bot1, Bot* &bot2);